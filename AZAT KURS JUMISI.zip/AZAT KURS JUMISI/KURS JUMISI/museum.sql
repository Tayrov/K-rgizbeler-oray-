-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 09, 2022 at 06:08 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `museum`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `phone`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Ramuza', 1234567, '1234567', '2022-12-08 11:30:03', '2022-12-08 11:30:03');

-- --------------------------------------------------------

--
-- Table structure for table `eksponats`
--

CREATE TABLE `eksponats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `eksponats`
--

INSERT INTO `eksponats` (`id`, `name`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Qırmanda', 'Nikolay Grigoryevich Karaxan (1900. 17. 5, Tawlıq Qarabaǵ tolıq huqıqlı wálayatı — 1970. 18. 6, Tashkent) — Ózbekstan xalıq súwretshisi (1950). 1908-jıldan Ózbekstanda. Túrkistan úlke súwretshilik mektebinde tálim alǵan (1918-21). Tashkent súwretshilik bilim jurtında sabaq bergen (1925-41). Karaxan dóretpelerinde ózbek xalqiniń turmısı hám miynetin, tábiyat tábiyat kórinislerin reńli taxtalarda sáwlelendirgen: \" Oraqshılardıń isten qaytıwı\" (1927), \" Sirdarya jaǵasındaǵı bazar\" (1929 ), \" Ǵálle órimi\" (1930 ), \" Buxarada qurılıs\" (1933), \" Jumısqa ketip atır\" (1934), \" Awqatlanıw mezgili\" (1935) hám basqalar 30-jıllardıń aqırlarınan dóretpelerinde respublika tábiyat kórinisilerin sáwlelendire basladı, kisilerdi de tábiyat kórinisiler fonında súwretledi (\" Hayallar ǵállezarda\", 1936 ; \" Ǵállae elep atırǵan áyel\", 1946 ; \" Nanay jolı\", 1954; \" Altın gúz\", 1957; \" Jasnap atırǵan oypatlıq\", 1958; \" Altın simfoniya\", 1965; \" Sońǵı nur\", 1969 hám b.). Kóplegen súwretshiler (atap aytqanda, R. Ahmedov, Z. Inog\'omov hám b.) Karaxanniń shákirtleri bolıp tabıladı. Karaxan dóretpeleri respublika hám shet mámleketler muzeylrri hám jeke jıynaqlarda saqlanadı.', 'images/1670536169.jpg', '2022-12-08 16:49:29', '2022-12-08 16:49:29'),
(2, 'Orıs toǵay qosıqları', 'Ózbekstan, Qaraqalpaqstan Toliq huqıqlı Respublikası, Nókis, Igor Savitskiy muzeyi (Nókis kórkem óner muzeyi), Ańshı N. M. Nedbaylo (1971) Geyde Shól Luvri dep atalatuǵın bul muzey 1966 -jılda ashılǵan bolıp, 82000 den artıq buyımlardan ibarat kolleksiyani saqlaydı. áyyemgi buyımlardan tartıp, xalıq ámeliy kórkem óneri, ózbek súwretleytuǵın kórkem óneri hám ayriqsha tárizde dúnyadaǵı ekinshi iri orıs avangard kolleksiyasi.', 'images/1670536441.jpg', '2022-12-08 16:54:01', '2022-12-08 16:54:01'),
(3, 'Brigadanıń atızǵa shıǵıwı', 'Aleksandr Nikolayevich Volkov (1886. 19. 8, Ferǵana -1957. 17. 12, Tashkent) — Ózbekistan xalıq súwretshisi (1946 ). Tashkent súwretshilik bilim jurtında oqıtıwshı (1919—46 ). Dóretiwdi rangtasvir dóretpeler sızıw menen baslaǵan (\" Anarli shayxana\", 1924, Tretyakov galereyasında ), \" Túyeler sahrada\", \" Sázendeler\", \" Ana\", \" Qazaq qızi\" (hámmesi —1926, Moskvada, súwretshiniń shańaraǵında ), \" Terimshi qızlar\" (1932, Tretyakov galereyasında ), \" Temirshiniń ustaxanasi\" (1929 ), \" Shohimardonda tús waqtı\" (1933, ekewi Arxangelsk súwretleytuǵın kórkem óner muzeyinde) dóretpelerinde Ózbekistan tábiyat kórinisileri hám adamların gewdelentirgen. Dóretpelerinde milliy xarakter, miynetsúyerlik, turmıs zawıqı sáwlelendirilgen (\"Brigadaniń dalaǵa shıǵıwı\", 1932—33; \" Jolsızlıqqa hújim\", 1932—34, ekewi Qaraqalpaqstan kórkem óner muzeyinde; \" Ekskavatorlardi jıynaw\", 1935, Ózbekstan kórkem óner muzeyinde). Tábiyat kórinisiler (Ferǵana kórinisleri sáwlelendirilgen \" Taw awılı\" gruppası, 1926—27), portretlar (Hamza, 1946—56, Qaraqalpaqstan kórkem óner muzeyinde; avtoportretlar, 1934, 1944, Ózbekstan kórkem óner muzeyinde), natyurmortlar (\" Atız gulleri\", 1955, Ózbekstan kórkem óner muzeyinde) da jaratqan.', 'images/1670536673.jpg', '2022-12-08 16:57:53', '2022-12-08 16:57:53');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_12_08_065800_create_eksponats_table', 1),
(5, '2022_12_08_070005_create_admins_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eksponats`
--
ALTER TABLE `eksponats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `eksponats`
--
ALTER TABLE `eksponats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
